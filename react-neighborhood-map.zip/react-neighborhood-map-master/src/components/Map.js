import React, { Component } from 'react'
import ListLocations from './ListLocations'

let markers = [
  { title: 'Princess Nourah Bint Abdul Rahman University',
    location: { "lat": 24.8464613, "lng": 46.7247308 }},
  { title:'King Saud University',
    location:{ 'lat': 24.7224191, 'lng': 46.6270967 }},
  { title:'Imam Muhammad Ibn Saud Islamic University',
    location: { 'lat' : 24.8135951, 'lng' : 46.7019289 }},
  { title:'Prince Sultan University', 
    location: { 'lat' : 24.7347335,'lng' : 46.6980411 }},
  {title:'Al Yamamah University', 
    location: { 'lat' : 24.8625975,'lng' : 46.5918403 }},
]
class Map extends Component {

  state = {
    map: {},
    center: {},
    infowindow: {},
    markers: [],
    mapMarkers: [],
    defaultIcon: {},
    highlightedIcon: {}
  }

  
  initMap(){
    return new window.google.maps.Map(document.getElementById('map'), {
      center: {"lat": 24.8464613, "lng": 46.7247308 },
      zoom: 11
    })
  }
  
  initSetup = () => {
    let center =  { title: 'Princess Nourah Bint Abdul Rahman University',
     location: {"lat": 24.8464613, "lng": 46.7247308 }}

    let map = this.initMap()
    let infowindow = new window.google.maps.InfoWindow({maxWidth: 200})
    this.addMarkers(map, markers, infowindow)
    this.setState({
      map: map,
      markers: markers, 
      center: center, 
      infowindow: infowindow})
  }
  //load Map
  componentDidMount() {
    window.initSetup = this.initSetup;
    function loadJS(src) {
        var ref = window.document.getElementsByTagName("script")[0];
        var script = window.document.createElement("script");
        script.src = src;
        script.async = true;
        ref.parentNode.insertBefore(script, ref);
    }
    loadJS(
      "https://maps.googleapis.com/maps/api/js?libraries=places,drawing,geometry&key=AIzaSyDOnY8J216-Mt_FemXha_v98czUWAdjmC0&callback=initSetup"
    );
  }


  // fetch data from wiki
  fetchFromWikipedia = (marker, infowindow, map) => {
    const search = marker.title.split(' ').join('_')
    const url = 'https://en.wikipedia.org/w/api.php?action=query&origin=*&prop=extracts&exintro&titles=' + search + '&format=json&utf8'
    let extract = ''
    const outerMap = this
    // Using fetch
    fetch( url, {
      method: 'POST',
      headers: new Headers( {
          'Api-User-Agent': 'Example/1.0'
      } )
    } ).then( function ( response ) {
      if ( response.ok ) {
          return response.json();
      }
      throw new Error( 'Network response was not working: ' + response.statusText );
    } ).then( function ( data ) {
      // do something with data
      const pages = data.query.pages
      extract = pages[Object.keys(pages)[0]].extract
      const firstParagraph = extract.slice(0, extract.indexOf('</p>') + '</p>'.length)
      const pageLink = `<a href="https://en.wikipedia.org/wiki/${search}">For more information, visit ${search} on Wikipedia website</a>`

      outerMap.addtoInfoWindow(marker, infowindow, map, firstParagraph + pageLink)
    });
  }
  addMarkers = (map, markers, infowindow) => {

    const outerMap = this
    const defaultIcon = this.makeMarkerIcon('0091ff')
    const highlightedIcon = this.makeMarkerIcon('FFFF24')
    let mapMarkers = []

    markers.forEach((marker) => {
      let mark = new window.google.maps.Marker({
        position: marker.location,
        map: map,
        title: marker.title,
        icon: defaultIcon
      })
      mapMarkers.push(mark)

      // To open InfoWindow
      mark.addListener('click', function() {
        outerMap.openInfoWindow(mark, infowindow)
      })

     // To change color
      mark.addListener('mouseover', function() {
        this.setIcon(highlightedIcon)
      })

      mark.addListener('mouseout', function() {
        this.setIcon(defaultIcon)
      })
    })
    this.setState({
       mapMarkers: mapMarkers,
       defaultIcon: defaultIcon,
       highlightedIcon: highlightedIcon})

  }

  addtoInfoWindow = (marker, infowindow, map, wikiData) => {
    infowindow.marker = marker
    infowindow.setContent('<div>' + marker.title + '</div>' + '<div>' + wikiData + '</div>')
    infowindow.open(map, marker)
    infowindow.addListener('closeclick', function() {
      infowindow.marker = null
    })
  }

  
  openInfoWindow = (marker, infowindow, map) => {
    if (infowindow.marker !== marker) {
      this.fetchFromWikipedia(marker, infowindow, map)
    }
  }

  
  makeMarkerIcon = (markerColor) => {
    let markerImage = new window.google.maps.MarkerImage(
      'http://chart.googleapis.com/chart?chst=d_map_spin&chld=1.15|0|'+ markerColor +
      '|40|_|%E2%80%A2',
      new window.google.maps.Size(21, 34),
      new window.google.maps.Point(0, 0),
      new window.google.maps.Point(10, 34),
      new window.google.maps.Size(21,34))
    return markerImage
  }

  
  render() {
    return (
      <div>
        <ListLocations
          key ="map"
          infowindow={this.infowindow} markers={markers}
          mapMarkers={this.mapMarkers} defaultIcon={this.defaultIcon}
          highlightedIcon={this.highlightedIcon} addMarkers={this.addMarkers}
          openInfoWindow={this.openInfoWindow} />

        <div id='map'></div>
      </div>
    )
  }
}
export default Map

